// These are the Node.js packages we'll use
var smartspaces = require('smartspaces');
var hlcserver = require('hlc-server');
var jsonsilo = require('json-silo');


// These are the directories we'll use for the quickyActive demo
var MY_DIRECTORIES = [ { title: "My dumb space", value: "dumb" },
                       { title: "-", value: "" } ];


// Now we instantiate each of the packages with the given options
var ui = new smartspaces();
var server = new hlcserver( { useCors: true,
                              barnowl: { n: 1 } } );
var silo = new jsonsilo( { useCors: true,
                           password: null,
                           directories: MY_DIRECTORIES } );


// Here we connect the HLC server with a continuous source of fake data
server.bind( { protocol: 'test', path: 'default' } );


// Here we write to the console to feel good about everything running
console.log("quickyActive: wow, that was fast!");
